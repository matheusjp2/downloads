local targetID = nil

-- escape when attacking will reset hold target
onKeyPress(function(keys)
    if keys == "Escape" and targetID then
        targetID = nil
    end
end)

macro(100, "Ataque Target [ESC]", nil, function()
  if g_game.isAttacking()
then
oldTarget = g_game.getAttackingCreature()
  end
  if (oldTarget and oldTarget:getPosition())
then
if (not g_game.isAttacking() and getDistanceBetween(pos(), oldTarget:getPosition()) <= 8) then

if (oldTarget:getPosition().z == posz()) then
        g_game.attack(oldTarget)
      end
    end
  end
end)

onKeyDown(function(keys)

if keys == "Escape" then
    oldTarget = nil
g_game.cancelAttack()
  end
end)

UI.Separator()

macro(20, "Attack Todos", function()
  for i,spec in ipairs(getSpectators()) do
    if (getDistanceBetween(player:getPosition(), spec:getPosition())  <= 10 and spec:isPlayer() and player:getName() ~= spec:getName() and spec:getEmblem() ~= 1)  then
      if (not target()) or (target() and (target():getHealthPercent() > spec:getHealthPercent()) or (not target():canShoot())) then
        attack(spec)
      end
    end
  end
end)

UI.Separator()

macro(20, "Attack System", function()
  for i,spec in ipairs(getSpectators()) do
    if (getDistanceBetween(player:getPosition(), spec:getPosition())  <= 10 and spec:isPlayer() and player:getName() ~= spec:getName() and spec:getEmblem() == 2)  then
      if (not target()) or (target() and (target():getHealthPercent() > spec:getHealthPercent()) or (not target():canShoot())) then
        attack(spec)
      end
    end
  end
end)

UI.Separator()

macro(20, "Attack Pk", function()
  for i,spec in ipairs(getSpectators()) do
    if (getDistanceBetween(player:getPosition(), spec:getPosition())  <= 10 and spec:isPlayer() and player:getName() ~= spec:getName() and spec:getEmblem() ~= 1 and spec:getSkull() > 0)  then
      if (not target()) or (target() and (target():getHealthPercent() > spec:getHealthPercent()) or (not target():canShoot())) then
        attack(spec)
      end
    end
  end
end)

UI.Separator()

macro(500, "stamina", function()
    if stamina() < 2400 then
        use(11372)
    end
end)

UI.Separator()

function superDash()
 if not parent then
    parent = panel
  end
  local switch = g_ui.createWidget('BotSwitch', parent)
  switch:setId("superDashButton")
  switch:setText("Super Dash")
  switch:setOn(storage.superDash)
  switch.onClick = function(widget)
    storage.superDash = not storage.superDash
    widget:setOn(storage.superDash)
  end

  onKeyPress(function(keys)
    if not storage.superDash then
      return
    end
    consoleModule = modules.game_chat
    if (keys == "W" or keys == "Up") then
        moveToPos = {x = posx(), y = posy()-6, z = posz()}
        dashTile = g_map.getTile(moveToPos)
        if dashTile then
          g_game.use(dashTile:getTopThing())
        end
    elseif (keys == "A" or keys == "Left") then
        moveToPos = {x = posx()-7, y = posy(), z = posz()}
        dashTile = g_map.getTile(moveToPos)
        if dashTile then
          g_game.use(dashTile:getTopThing())
        end
elseif (keys == "S" or keys == "Down") then
        moveToPos = {x = posx(), y = posy()+6, z = posz()}
        dashTile = g_map.getTile(moveToPos)
        if dashTile then
          g_game.use(dashTile:getTopThing())
        end
    elseif (keys == "D" or keys == "Right") then
        moveToPos = {x = posx()+7, y = posy(), z = posz()}
        dashTile = g_map.getTile(moveToPos)
        if dashTile then
          g_game.use(dashTile:getTopThing())
        end
    end
  end)
end
superDash()
